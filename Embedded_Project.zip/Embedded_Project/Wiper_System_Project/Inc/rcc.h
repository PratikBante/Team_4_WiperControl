#ifndef RCC_H
#define RCC_H

void config_rcc(void *ptr);

#endif
